"""FastAPI HTTP layer."""

