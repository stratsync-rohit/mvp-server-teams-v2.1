"""Shared utilities."""

