"""Microsoft provider SDK boundaries."""
