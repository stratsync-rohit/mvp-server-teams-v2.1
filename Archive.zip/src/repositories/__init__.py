"""Mongo-backed persistence boundaries."""
