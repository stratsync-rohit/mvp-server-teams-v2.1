"""Bot activity handlers."""

