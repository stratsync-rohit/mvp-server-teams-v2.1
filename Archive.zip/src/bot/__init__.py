"""Microsoft Bot Framework integration."""

